#ifndef CAN_H
#define CAN_H

#define ID_CHECK 0x04901001

/*
 * esse ID está aqui meramente para simular um erro
 * não é um erro real da FCCM
 * troocar para 0x04901000, assim que o código novo
 * chegar da FT
 */
#define ID_ERROR 0x04901000 //o valor aqui é uma simulação de erro

/*
o protocolo vai ser dividido em duas partes:

um header vai ser criado para o envio de informações da fccm,
e o outro vai ser criado para apenas as mensagens de erro
*/

#define BMS_ID 0x04800000

/*
 * para a comunicação da fccm, esse ID específico é criado para
 * se comunicar com o BMS
 */

void config(void);
void declare_can_CHECK(void);
void declare_can_ERROR(void);
void declare_can_BMS(void);
void Slice_DATA(void);
void send_FCCM(void);
void Receive_CAN_Message(void);

#endif
